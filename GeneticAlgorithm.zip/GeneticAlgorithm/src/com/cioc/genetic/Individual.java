package com.cioc.genetic;

public class Individual {

}