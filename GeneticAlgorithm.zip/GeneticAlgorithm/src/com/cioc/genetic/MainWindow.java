package com.cioc.genetic;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swtchart.Chart;
import org.eclipse.swtchart.IAxisSet;
import org.eclipse.swtchart.ILineSeries;
import org.eclipse.swtchart.ISeriesSet;
import org.eclipse.swtchart.ILineSeries.PlotSymbolType;
import org.eclipse.swtchart.ISeries.SeriesType;

public class MainWindow {

	protected Shell shell;
	private Text txtString, txtAlphabet;
	private Spinner spnPopulation, spnMutation;
	private Button btnStart, btnStop, chkElitism, btnRefreshChart;
	private Label lblGenerations, lblFitness, lblPopulation, lblMutation, lblBestFit, lblDuration;
	private List<Individual> members;
	private int generationCount, mutationRate;
	private boolean stop, elitism;
	private Individual bestIndividual;
	private Chart chart;
	private ILineSeries seriesChart;
	private IAxisSet axisSetChart;
	private List<Individual> bestIndividuals;
	private long startTime;

	public static void main(String[] args) {
		try {
			MainWindow window = new MainWindow();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	protected void createContents() {
		shell = new Shell();
		shell.setSize(800, 500);
		shell.setText("String Search");
		shell.setLayout(new GridLayout(1, false));
		
		Group group = new Group(shell, SWT.NONE);
		group.setLayout(new GridLayout(3, false));
		group.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label lblStringToSearch = new Label(group, SWT.NONE);
		lblStringToSearch.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblStringToSearch.setText("String to search:");
		
		txtString = new Text(group, SWT.BORDER);
		txtString.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				btnStart.setEnabled(!txtString.getText().equals(""));
			}
		});
		txtString.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		btnStart = new Button(group, SWT.NONE);
		btnStart.setText("Start");
		btnStart.setEnabled(false);
		btnStart.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Util.ALPHABET = txtAlphabet.getText();
				
				final String string = txtString.getText().trim();
				final int initialPopulationSize = spnPopulation.getSelection();
				bestIndividuals = new ArrayList<Individual>();
				startTime = System.nanoTime();
				
				Thread thread = new Thread() {
				    public void run() {
				    	
				    }  
				};
				thread.start();
			}
		});
		
		Label lblAlphabet = new Label(group, SWT.NONE);
		lblAlphabet.setText("Alphabet:");
		
		txtAlphabet = new Text(group, SWT.BORDER);
		txtAlphabet.setText("abcdefghijklmnopqrstuvwxyz ");
		txtAlphabet.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		btnStop = new Button(group, SWT.NONE);
		btnStop.setEnabled(false);
		btnStop.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnStop.setText("Stop");
		btnStop.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stop = true;
			}
		});
		
		Group group_1 = new Group(shell, SWT.NONE);
		group_1.setLayout(new FillLayout(SWT.HORIZONTAL));
		group_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Composite composite = new Composite(group_1, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));
		
		Label lblSizeOfThe = new Label(composite, SWT.NONE);
		lblSizeOfThe.setText("Size of the initial population:");
		
		spnPopulation = new Spinner(composite, SWT.BORDER);
		spnPopulation.setMinimum(2);
		spnPopulation.setMaximum(99999999);
		spnPopulation.setSelection(100);
		
		Composite composite_1 = new Composite(group_1, SWT.NONE);
		composite_1.setLayout(new GridLayout(3, false));
		
		Label lblMutationProbability = new Label(composite_1, SWT.NONE);
		lblMutationProbability.setText("Mutation probability:");
		
		spnMutation = new Spinner(composite_1, SWT.BORDER);
		spnMutation.setMinimum(0);
		spnMutation.setMaximum(100);
		spnMutation.setSelection(1);
		spnMutation.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				mutationRate = spnMutation.getSelection();
			}
		});
		
		Label label = new Label(composite_1, SWT.NONE);
		label.setText("%");
		
		Composite composite_4 = new Composite(group_1, SWT.NONE);
		composite_4.setLayout(new GridLayout(2, false));
		
		chkElitism = new Button(composite_4, SWT.CHECK);
		chkElitism.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, true, 1, 1));
		chkElitism.setText("Elitism");
		chkElitism.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				elitism = chkElitism.getSelection();
			}
		});
		
		btnRefreshChart = new Button(composite_4, SWT.CHECK);
		btnRefreshChart.setText("Refresh Chart");
		
		Group group_2 = new Group(shell, SWT.NONE);
		group_2.setLayout(new FillLayout(SWT.HORIZONTAL));
		group_2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		Composite composite_2 = new Composite(group_2, SWT.NONE);
		composite_2.setLayout(new GridLayout(2, false));
		
		Label lblTotalGenerations = new Label(composite_2, SWT.NONE);
		lblTotalGenerations.setText("Total generations:");
		
		lblGenerations = new Label(composite_2, SWT.NONE);
		lblGenerations.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblGenerations.setText("...");
		
		Label lblHighestFitness = new Label(composite_2, SWT.NONE);
		lblHighestFitness.setText("Highest fitness:");
		
		lblFitness = new Label(composite_2, SWT.NONE);
		lblFitness.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblFitness.setText("...");
		
		Label lblTotalPopulation = new Label(composite_2, SWT.NONE);
		lblTotalPopulation.setText("Total population:");
		
		lblPopulation = new Label(composite_2, SWT.NONE);
		lblPopulation.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblPopulation.setText("...");
		
		Label lblMutationRate = new Label(composite_2, SWT.NONE);
		lblMutationRate.setText("Mutation rate:");
		
		lblMutation = new Label(composite_2, SWT.NONE);
		lblMutation.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblMutation.setText("...");
		
		Label lblBestFitMember = new Label(composite_2, SWT.NONE);
		lblBestFitMember.setText("Best fit:");
		
		lblBestFit = new Label(composite_2, SWT.NONE);
		lblBestFit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblBestFit.setText("...");
		
		Label lblDurationTitle = new Label(composite_2, SWT.NONE);
		lblDurationTitle.setText("Duration:");
		
		lblDuration = new Label(composite_2, SWT.NONE);
		lblDuration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblDuration.setText("...");
		
		Composite composite_3 = new Composite(group_2, SWT.NONE);
		composite_3.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		chart = new Chart(composite_3, SWT.NONE);
		chart.getTitle().setText("");
		chart.getLegend().setPosition(SWT.BOTTOM);
		chart.getAxisSet().getXAxis(0).getTitle().setText("Generations");
		chart.getAxisSet().getYAxis(0).getTitle().setText("Fitness");
		ISeriesSet seriesSetChart = chart.getSeriesSet();
		seriesChart = (ILineSeries) seriesSetChart.createSeries(SeriesType.LINE, "Fitness");
		seriesChart.setSymbolType(PlotSymbolType.NONE);
		seriesChart.setLineWidth(2);
		seriesChart.setYSeries(new double[] {});
		axisSetChart = chart.getAxisSet();
	}
	
	private void refreshChart() {
		double[] points = new double[bestIndividuals.size()];
		
		//for(int i=0; i<bestIndividuals.size(); i++)
		//	points[i] = bestIndividuals.get(i).getFitness();
		
		seriesChart.setYSeries(points);
		
		axisSetChart.adjustRange();
		
		chart.redraw();
	}
	
	private void enableUIComponents(boolean enabled) {
		txtString.setEnabled(enabled);
		txtAlphabet.setEnabled(enabled);
		btnStart.setEnabled(enabled);
		spnPopulation.setEnabled(enabled);
		btnStop.setEnabled(!enabled);
	}
	
	private void restartUI() {
		lblBestFit.setText("...");
		lblFitness.setText("...");
		lblGenerations.setText("...");
		lblMutation.setText("...");
		lblPopulation.setText("...");
		lblDuration.setText("...");
	}
}