package com.cioc.genetic;

import java.util.Random;

public class Util {
	public static String ALPHABET = "abcdefghijklmn�opqrstuvwxyz "; // default alphabet
	
	public static String getRandomChar() {
		Random r = new Random();
		
		return ALPHABET.charAt(r.nextInt(ALPHABET.length())) + "";
	}
}
